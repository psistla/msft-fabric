# Internal Meeting Prep: Architecture Rationale & Fabric-First Defense

**Purpose:** Equip the internal team to walk through the architecture, defend the Fabric-first recommendation, and articulate why this works specifically for this client.

**Audience:** Internal Slalom team only — not client-facing.

**Directive:** Present both architectures to the client, but land on Option B (Microsoft Fabric). Option A (Azure SQL) serves as the conservative reference point that makes Fabric's value proposition clear.

---

## The One-Sentence Pitch

> "Starting on Azure SQL means building an architecture the client will outgrow and replace. Starting on Fabric means building once on the platform they'll run for the next decade — and FabCon Atlanta just confirmed Microsoft is betting the company on it."

---

## FabCon Atlanta 2026 Validation (March 16–20 — Last Week)

FabCon Atlanta was the largest Fabric conference yet — 8,000 attendees, co-located with the first-ever SQLCon, and Microsoft used it to make an explicit strategic statement: **Fabric is no longer "just" an analytics layer — it is the control plane for the entire enterprise data estate.**

### Announcements That Directly Validate Our Architecture

| Announcement | What It Is | Why It Matters for This Client |
|-------------|-----------|-------------------------------|
| **31,000+ Fabric customers** | Fabric is now the fastest-growing data platform in Microsoft history, 2.5 years post-GA. 74% of Fortune 500 use it. | "Too new" objection is dead. This is mainstream enterprise adoption. |
| **Materialized Lake Views (GA)** | Simplifies medallion architecture (Bronze → Silver → Gold) in Spark SQL and PySpark. Always up-to-date pipelines with no manual orchestration. | Directly simplifies our proposed layered architecture. Gold-layer views auto-refresh when Silver data changes — reduces pipeline complexity for the lean team. |
| **Runtime 2.0 (Preview)** | Apache Spark 4.x, Delta Lake 4.x, Scala 2.13. Purpose-built for large-scale data computation. | Future-proofs the Spark workloads we'd use for entity resolution and feature engineering. Client benefits from latest Delta optimizations without managing infrastructure. |
| **Fabric IQ** | Shared semantic framework that turns Power BI semantic models into AI-ready business context. Part of Microsoft IQ (Work IQ + Foundry IQ + Fabric IQ). | The Power BI semantic models we're building in Phase 1–2 become the exact foundation Fabric IQ uses to power AI agents in Phase 4. Our semantic layer investment is forward-compatible with Microsoft's AI strategy. |
| **Agentic Copilot in Notebooks** | Deeper context awareness, reasoning over workspace, generating code with greater speed and precision. | Accelerates the lean team's Spark development in Silver-layer transformations. Copilot helps bridge the T-SQL → PySpark gap. |
| **Notebook Lakehouse Auto-Binding for Git** | Notebooks automatically resolve the correct Lakehouse as they move across Git-connected workspaces (dev → test → prod). | Directly addresses our CI/CD architecture. No manual rebinding when promoting notebooks across environments. Reduces operational overhead for the lean team. |
| **Fabric Data Factory: Outbound Access Protection (OAP)** | Pipelines, Dataflows Gen2, and Copy jobs connect only to approved destinations. | Enterprise-grade security for the lending client. Prevents data exfiltration — addresses regulatory compliance requirements. |
| **SQLCon Co-Location** | Microsoft converging the database and analytics communities into one event. Session: "A Guide to Making the Most of Your SQL Skills Using Microsoft Fabric." | Microsoft is explicitly telling SQL-fluent teams that Fabric IS their platform. The co-location is a product strategy signal, not just a conference logistics decision. |
| **Coca-Cola Case Study** | Coca-Cola VP of Global Marketing Technologies quoted: "Microsoft Fabric is helping us evolve our data foundation into a more unified, AI-ready platform." | Enterprise-scale proof point. If Coca-Cola runs their global marketing technology on Fabric, a small business lender's data volume is well within comfort zone. |
| **Database Hub** | Unified management for databases across edge, cloud, and Fabric. SQL Server 2025 growing 2x faster than previous version. | Signals that Microsoft is unifying transactional and analytical workloads. The client's existing SQL MI fits into this convergence story — Mirroring is the bridge. |
| **Mirroring Enhancements** | Extended capabilities including Change Delta Feed and Snowflake Mirroring Support for Views (Preview). | Validates our Phase 1 MI Mirroring quick-win. Mirroring is becoming the default ingestion pattern — exactly what we proposed. |

### The Strategic Signal

Microsoft's Arun Ulag framed it explicitly: Fabric is the platform for building an AI-ready data foundation through four steps — unify your data estate, process and harmonize data, curate semantic meaning, and power AI agents. **That is literally our four-phase roadmap.** Our architecture is aligned with Microsoft's stated platform direction.

---

## Defending the Fabric-First Choice: Objection Handling

### Objection 1: "Our team knows SQL, not Spark"

**Response:** So does Fabric. Fabric Warehouse supports full T-SQL DML — INSERT, UPDATE, DELETE, MERGE. Our architecture uses Fabric Warehouse as the **primary** transformation engine for the Silver and Gold layers. The team writes the same SCD Type 2 MERGE patterns they already know, quality gate stored procedures in T-SQL, reconciliation logic in T-SQL — all inside Fabric Warehouse.

Spark notebooks are used **selectively** for three specific workloads where Spark genuinely adds value: JSON flattening from LendFoundry API responses, cross-source entity resolution on DimBorrower (fuzzy matching), and Phase 4 ML feature engineering.

FabCon Atlanta literally ran a session called **"A Guide to Making the Most of Your SQL Skills Using Microsoft Fabric"** — Microsoft is designing for this exact audience.

The new agentic Copilot in notebooks also helps bridge the gap — it generates Spark code with workspace context awareness, reducing the learning curve.

### Objection 2: "Fabric is too new / not enterprise-ready"

**Response:** 31,000 customers. 74% of Fortune 500. Coca-Cola runs global marketing technology on it. 2.5 years post-GA. 8,000 people at FabCon Atlanta last week. This is not a preview product — it's Microsoft's fastest-growing data platform in history.

For specific enterprise-readiness: Outbound Access Protection (announced last week) ensures pipelines connect only to approved destinations. Purview is natively integrated. OneLake Security (centralized access control across all engines) is in preview. Private endpoints are supported.

### Objection 3: "Cost is unpredictable with shared capacity"

**Response:** Three cost control levers:

1. **Capacity pause/resume** — for batch-oriented lending workloads, pause F64 on nights and weekends → 40–60% savings ($30K–$44K/yr).
2. **Reserved capacity** — 1-year commitment reduces F64 from $6,144 to ~$4,300/mo (30% savings).
3. **Capacity monitoring** — Fabric Capacity Metrics app deployed from day one. CU utilization tracked. If consistently < 40%, downgrade to F32. If > 70%, planned scale-up to F128.

Estimated annual infrastructure: **$84K–$100K** (Fabric) vs. **$107K–$160K** (Azure SQL + ADLS + ADF + Power BI Premium separately). Fabric is actually cheaper infrastructure — the premium is in the learning investment, which is a one-time cost.

### Objection 4: "Why not start Azure SQL and migrate later?"

**Response:** Because "migrate later" means:

- Rebuild all ADF pipelines as Fabric Data Pipelines
- Migrate Azure SQL stored procedures to Fabric Warehouse (compatible but not zero-effort)
- Recreate ADLS Gen2 lifecycle policies in OneLake
- Reconfigure Power BI from Import/DirectQuery to Direct Lake
- Redo Purview scanning configurations
- Retrain the team on a second platform

Every dollar and hour spent on Azure SQL infrastructure is sunk cost that gets replaced, not evolved. The governance framework, dimensional model, and KPI definitions transfer — but the platform plumbing gets rebuilt. For a lean team, doing this twice is not realistic.

Starting on Fabric means building once. The MI Mirroring quick-win gives the team immediate access to existing data while the governed architecture is built alongside it.

### Objection 5: "What if the client insists on Azure SQL?"

**Response:** We have Option A documented and ready. We don't dismiss it — we present it as the conservative path with explicit trade-offs. The trade-off framework in the document is weighted for this client's priorities. If the client still chooses Azure SQL after seeing the analysis, we deliver it well. But our professional recommendation is Fabric, and we should be confident in stating that.

---

## Why This Works for THIS Client: Pain Point → Fabric Capability Map

| Client Pain Point | Root Cause | Fabric Capability | How It Solves It |
|------------------|-----------|-------------------|-----------------|
| **Point-to-point integration patterns** | No centralized orchestration. Each source connected ad-hoc to SQL MI. | Fabric Data Factory (metadata-driven pipelines) + OneLake as unified landing zone | One orchestration engine. Sources land in OneLake Bronze layer. New source = config rows, not new pipelines. < 2 hours to onboard. |
| **Distributed transformation logic** | Business rules scattered across MI stored procs, Excel, LendFoundry reports, NetSuite saved searches. | Fabric Warehouse (T-SQL) as single transformation engine + version-controlled in Git | All business rules in one place, one language (T-SQL), one version control system. MI discovery sprint extracts scattered logic; Fabric Warehouse consolidates it. |
| **Duplicated business logic across reports** | Same KPI calculated differently in different reports. No single governed definition. | Power BI semantic models (Direct Lake) as the enforced interface for all reporting | Semantic model = single source of KPI truth. All reports consume from semantic layer. Approval Rate is defined once, in DAX, in one place. |
| **Limited centralized metadata management** | No catalog, no glossary, no lineage. Knowledge lives in people's heads. | Purview (Fabric-integrated) — auto lineage, catalog, glossary, classification | Purview scans all Fabric items automatically. Lineage from source → pipeline → Lakehouse → Warehouse → semantic model → report is tracked without manual documentation. |
| **Manual reconciliation and validation** | No automated quality monitoring. Differences discovered manually after reports published. | Quality gates at each layer + automated GL reconciliation + anomaly detection | Bronze → Silver quality gates block bad data. GL reconciliation runs automatically post-load. Anomaly detection catches issues before users see them. |
| **Lean internal capacity** | Small team can't sustain custom integration, ad-hoc reporting, and quality firefighting. | Metadata-driven patterns + self-service analytics + Direct Lake (no refresh management) + Materialized Lake Views (auto-refresh) | Metadata framework reduces per-source effort. Self-service shifts report creation to business. Direct Lake eliminates refresh scheduling. MLVs (now GA) auto-refresh Gold layer. The platform does more so the team does less. |

---

## Presentation Strategy for the Client Meeting

### Structure

1. **Current state validation** (5 min) — "Here's what we heard, here's what we found in discovery. Does this match your experience?" Build credibility by reflecting their pain accurately.

2. **Shared principles** (5 min) — Single source of truth, layered architecture, semantic layer as contract, governance by design. These are non-negotiable regardless of platform. Get agreement here before platform discussion.

3. **Dimensional model** (10 min) — Walk through DimBorrower, DimLoan, FactOrigination, FactPayment. Show the KPI standardization table. Ask: "Is this the right definition of Approval Rate? Delinquency Rate?" This is where business engagement happens.

4. **Both architectures presented** (15 min) — Show Option A diagram, then Option B diagram. Walk through the components. Be factual, not dismissive of Option A.

5. **Trade-off framework** (10 min) — The weighted comparison table. Let the criteria speak. Highlight where their stated priorities (lean capacity, reporting-first, phased AI) align with Fabric's strengths.

6. **Recommendation with rationale** (5 min) — "Based on your priorities, our recommendation is Fabric. Here's why: you'd end up there anyway, the cost is comparable or lower, the governance integration is tighter, and FabCon Atlanta last week confirmed this is Microsoft's strategic platform for the next decade."

7. **Phased roadmap** (10 min) — Sprint-level Phase 1 walkthrough. Show the MI Mirroring quick-win. Show the Go/No-Go gates.

8. **Next steps** (5 min) — MI discovery sprint, source access requests, governance charter. These start regardless of platform choice.

### Key Talking Points for the Team

- "Fabric Warehouse speaks T-SQL. Your team's SQL skills are an asset, not a limitation."
- "31,000 organizations are already running on Fabric. This isn't early adoption — this is mainstream."
- "Starting on Azure SQL means building twice. Starting on Fabric means building once."
- "Materialized Lake Views — announced as GA last week at FabCon Atlanta — automate exactly the medallion pattern we're proposing. The platform is accelerating toward our architecture."
- "The semantic models we build in Phase 1 become the foundation for AI agents in Phase 4 through Fabric IQ. Your KPI investment compounds."
- "MI Mirroring on day one gives you Fabric access to existing data immediately — zero pipeline development needed."

---

## Risk Acknowledgment (Be Honest About These)

| Risk | Our Mitigation | What to Say |
|------|---------------|-------------|
| Fabric Warehouse has fewer T-SQL features than Azure SQL (no linked servers, no SQL Agent, limited cross-database queries) | All transformation logic is self-contained within Fabric Warehouse schemas. No linked servers needed — data moves through pipelines, not linked queries. Scheduling via Fabric Data Pipelines, not SQL Agent. | "Fabric Warehouse covers 90%+ of T-SQL workloads. The gaps are in legacy patterns (linked servers, SQL Agent) that we're replacing with modern equivalents regardless of platform." |
| Capacity throttling under concurrent workloads | F64 baseline with monitoring from day one. Pipeline scheduling staggered to avoid peaks. Scale to F128 temporarily for heavy processing windows. | "We size conservatively and monitor actively. If we see throttling, we scale up for the window and scale back down." |
| Fabric CI/CD is improving but not as mature as Azure SQL toolchain | Git Integration is GA. Deployment Pipelines are functional. Notebook auto-binding (announced last week) closes a key gap. Some artifact types may still have edges. | "The CI/CD story has improved significantly. The Git integration and deployment pipelines cover our core artifacts. We'll flag any gaps we encounter and have workarounds ready." |
| Direct Lake framing/fallback | Monitor via Capacity Metrics app. Optimize Gold tables with V-ORDER. Keep dimensions small. | "Direct Lake is the default mode. Fallback to DirectQuery is transparent and automatic. We optimize to minimize fallback frequency." |

---

*Built for scale by Prasanth Sistla*
